// content.js - VERSION FINALE (Correction Double Carte)

let isWindowMoved = false;

// 1. Démarrage
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", launchMastoStyle);
} else {
    launchMastoStyle();
}

function launchMastoStyle() {
    // Vérif Mastodon
    const isMastodon = document.querySelector('div#mastodon') || 
                       document.querySelector('script#mastodon-initial-state') ||
                       document.querySelector('.app-body');

    if (!isMastodon) return;

    console.log("MastoStyle: Démarrage...");

    injectCSSWrapper();
    createFAB();

    const observer = new MutationObserver(() => {
        if (!document.getElementById('ms-fab')) createFAB();
        moveComposeWindow();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    loadColors();
}

// 2. Déplacer la fenêtre (Teleport)
function moveComposeWindow() {
    const originalForm = document.querySelector('.compose-form');
    if (!originalForm) return;
    if (originalForm.parentElement.id === 'ms-moved-container') return;

    let container = document.getElementById('ms-moved-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'ms-moved-container';
        document.body.appendChild(container);
    }
    container.appendChild(originalForm);
}

// 3. Bouton Plume
function createFAB() {
    if (document.getElementById('ms-fab')) return;

    const fab = document.createElement('div');
    fab.id = 'ms-fab';
    fab.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>';
    document.body.appendChild(fab);

    fab.addEventListener('click', () => {
        document.body.classList.toggle('ms-compose-active');
        if (document.body.classList.contains('ms-compose-active')) {
            setTimeout(() => {
                const txt = document.querySelector('#ms-moved-container textarea');
                if (txt) txt.focus();
            }, 200);
        }
    });
}

// 4. Couleurs
function loadColors() {
    const defP = '#6364ff';
    const defBg = '#191b22';
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get(['primary', 'bg'], (data) => {
            updateCSS(data.primary || defP, data.bg || defBg);
        });
        chrome.runtime.onMessage.addListener((req) => {
            if (req.action === "updateStyle") updateCSS(req.settings.primary, req.settings.bg);
        });
    } else {
        updateCSS(defP, defBg);
    }
}

function injectCSSWrapper() {}

// 5. Le CSS (Design)
function updateCSS(primary, bg) {
    const styleId = 'ms-style-core';
    let styleTag = document.getElementById(styleId);

    const cssContent = `
        :root { --ms-primary: ${primary}; --ms-bg: ${bg}; }

        body, .app-body, .ui, .columns-area, .drawer__inner {
            background-color: var(--ms-bg) !important;
        }

        /* CARTES (Correction: Retrait de .status__wrapper pour éviter l'effet "pile") */
        .status, .detailed-status, article {
            background: linear-gradient(145deg, rgba(255,255,255,0.06), rgba(255,255,255,0.01)) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 18px !important;
            margin: 15px 10px !important;
            padding: 15px !important;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3) !important;
            transition: transform 0.2s;
        }
        .status:hover, article:hover {
            transform: translateY(-3px);
            border-color: var(--ms-primary) !important;
        }

        /* AVATARS CARRÉS */
        .account__avatar {
            border-radius: 6px !important;
            border: 2px solid var(--ms-primary) !important;
            padding: 1px; box-sizing: border-box;
        }
        
        /* FENÊTRE FLOTTANTE */
        .compose-form { display: block !important; }
        #ms-moved-container {
            display: none; position: fixed; bottom: 100px; left: 20px;
            width: 450px; max-width: 85vw;
            z-index: 2147483647 !important;
            background: var(--ms-bg);
            border: 1px solid var(--ms-primary);
            border-radius: 20px; padding: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.7);
            transform: translateZ(9999px);
        }
        #ms-moved-container .account__avatar { border: none !important; padding: 0 !important; }

        body.ms-compose-active #ms-moved-container {
            display: block !important;
            animation: ms-pop 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        /* FAB */
        #ms-fab {
            position: fixed; bottom: 25px; left: 25px;
            width: 60px; height: 60px;
            background: var(--ms-primary); border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: white; cursor: pointer;
            box-shadow: 0 5px 20px rgba(0,0,0,0.4);
            z-index: 2147483647; transition: 0.2s;
        }
        #ms-fab:hover { transform: scale(1.1); }
        body.ms-compose-active #ms-fab { background: #e0245e; transform: rotate(135deg); }

        @keyframes ms-pop { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
    `;

    if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = styleId;
        document.head.appendChild(styleTag);
    }
    styleTag.textContent = cssContent;
}

console.log("FIN DU FICHIER OK");