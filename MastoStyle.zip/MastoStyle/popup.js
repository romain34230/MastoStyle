document.addEventListener('DOMContentLoaded', () => {
  const themeSelector = document.getElementById('themeSelector');
  const primaryColor = document.getElementById('primaryColor');
  const bgColor = document.getElementById('bgColor');
  const saveBtn = document.getElementById('saveBtn');

  // Thèmes
  const themes = {
    modern: { primary: '#6364ff', bg: '#191b22' },
    cyber: { primary: '#ff0055', bg: '#0b0014' },
    forest: { primary: '#10b981', bg: '#0f172a' }
  };

  // Charger
  chrome.storage.local.get(['theme', 'primary', 'bg'], (data) => {
    if (data.theme) themeSelector.value = data.theme;
    if (data.primary) primaryColor.value = data.primary;
    if (data.bg) bgColor.value = data.bg;
  });

  // Changer
  themeSelector.addEventListener('change', (e) => {
    const val = e.target.value;
    if (themes[val]) {
      primaryColor.value = themes[val].primary;
      bgColor.value = themes[val].bg;
    }
  });

  // Sauvegarder
  saveBtn.addEventListener('click', () => {
    const settings = {
      theme: themeSelector.value,
      primary: primaryColor.value,
      bg: bgColor.value
    };
    
    chrome.storage.local.set(settings, () => {
      // Envoi sécurisé pour éviter l'erreur dans la console
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {action: "updateStyle", settings: settings}, (response) => {
            // Cette ligne rend l'erreur silencieuse si le script n'est pas prêt
            if (chrome.runtime.lastError) { console.log("Pas sur Mastodon"); }
          });
        }
      });
    });
  });
});